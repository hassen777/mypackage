# mypackage 
This package was created as an expample of how to create a package.

## build this package locally
```bash
python setup.py sdist bdist_wheel
```

## install this package locally
```bash
pip installWe love that you love Bito’s AI Code Completions!
You have hit your limit for AI Code Completions per day on your plan.
To receive more Completions, please upgrade your plan or contact mailto:support@bito.ai